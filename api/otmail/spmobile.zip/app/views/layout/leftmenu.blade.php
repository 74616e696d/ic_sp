<div id="left" class="span3">
		<ul class="nav nav-tabs nav-stacked">
		<li><a href=""><i class="icon-home"></i>&nbsp;Home</a></li>
		<li class="active"><a href=""><i class="icon-leaf"></i>&nbsp;Manage Previous Question</a></li>
		<li><a href=""><i class="icon-leaf"></i>&nbsp;Manage Previous Answer</a></li>
		<li><a href=""><i class="icon-leaf"></i>&nbsp;Manage Question</a></li>
		<li><a href=""><i class="icon-leaf"></i>&nbsp;Manage Answer</a></li>
		<li><a href=""><i class="icon-leaf"></i>&nbsp;Menu6</a></li>
		<li><a href=""><i class="icon-leaf"></i>&nbsp;Menu7</a></li>
		<li><a href=""><i class="icon-leaf"></i>&nbsp;Menu8</a></li>
		<li><a href=""><i class="icon-leaf"></i>&nbsp;Menu9</a></li>
		<li><a href=""><i class="icon-leaf"></i>&nbsp;Menu10</a></li>
		<li><a href=""><i class="icon-leaf"></i>&nbsp;Menu11</a></li>
		</ul>
</div>