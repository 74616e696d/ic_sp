<?php $base_url="http://localhost:8080/OnlineTest/"; ?>
<div class="span3" id="sidebar">
    <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
        <li class="active">
            <a href="{{$base_url}}admin/dashboard"><i class="icon-chevron-right"></i> Dashboard</a>
        </li>
        <li>
            <a href="{{$base_url}}admin/add_question"><i class="icon-chevron-right"></i>Add Question</a>
        </li>
        <li>
            <a href="{{$base_url}}admin/question_bank"><i class="icon-chevron-right"></i>Question Bank</a>
        </li>
        <li>
            <a href="{{$base_url}}admin/manage_comprehension"><i class="icon-chevron-right"></i>Manage Comprehension</a>
        </li>
         <li>
            <a href="{{$base_url}}admin/chapter_details"><i class="icon-chevron-right"></i>Add Chapter Details</a>
        </li>
        <li>
        <a href="{{$base_url}}admin/chapter_media"><i class="icon-chevron-right"></i>Chapter Media</a></li>
		 <li>
            <a href="{{$base_url}}admin/question_assignment"><i class="icon-chevron-right"></i>Assign Question</a>
        </li>
         <li>
            <a href="{{$base_url}}admin/manage_assigned_question"><i class="icon-chevron-right"></i>Manage Assigned Question</a>
        </li>
        <li>
            <a href="{{$base_url}}admin/add_exam"><i class="icon-chevron-right"></i>Add Exam</a>
        </li>
         <li>
            <a href="{{$base_url}}admin/exam"><i class="icon-chevron-right"></i>Manage Exam</a>
        </li>

         <li>
            <a href="{{$base_url}}admin/modeltest"><i class="icon-chevron-right"></i>Manage Model Test</a>
        </li>
       {{--  <li>
            <a href="{{$base_url}}admin/manage_syllabus"><i class="icon-chevron-right"></i>Manage Syllabus</a>
        </li>
        <li>
            <a href="{{$base_url}}admin/add_syllabus"><i class="icon-chevron-right"></i>Add Syllabus</a>
        </li>--}}
        <li>
            <a href="{{$base_url}}admin/upgrade_request"><i class="icon-chevron-right"></i>Manage Upgrade Request</a>
        </li>
        <li>
            <a href="{{$base_url}}admin/manage_choosen_category"><i class="icon-chevron-right"></i>
            Manage Choosen Category</a>
        </li>
        <li>
            <a href="{{$base_url}}admin/ask_list"><i class="icon-chevron-right"></i>
            Asked Questions</a>
        </li>
        <li><a href="{{$base_url}}admin/manage_notification"><i class="icon-chevron-right"></i>Manage Notification</a></li>
      <li><a href="{{$base_url}}admin/news/news_list"><i class="icon-chevron-right"></i>Manage News</a></li>
    </ul>
</div>
