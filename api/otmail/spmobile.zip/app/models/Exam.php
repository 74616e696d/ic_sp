<?php

class Exam extends Eloquent {
	protected $table = 'exam';
	protected $guarded = ['id'];
	public $timestamps=false;

	


}