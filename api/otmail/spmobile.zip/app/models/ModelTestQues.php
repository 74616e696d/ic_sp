<?php

class ModelTestQues extends Eloquent {

	protected $table = 'model_test_question';
	protected $guarded = ['id'];
	public $timestamps=false;

}