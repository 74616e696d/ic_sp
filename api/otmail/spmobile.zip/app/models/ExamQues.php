<?php

class ExamQues extends Eloquent {
	protected $table = 'exam_question';
	protected $guarded = ['id'];
	public $timestamps=false;


}