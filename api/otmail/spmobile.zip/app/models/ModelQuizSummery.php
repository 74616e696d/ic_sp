<?php

class ModelQuizSummery extends Eloquent {

	protected $table = 'model_quiz_summery';
	protected $guarded = ['id'];
	public $timestamps=false;

}