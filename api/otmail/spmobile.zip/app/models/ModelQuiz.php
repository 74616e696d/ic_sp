<?php

class ModelQuiz extends Eloquent {

	protected $table = 'model_quiz';
	protected $guarded = ['id'];
	public $timestamps=false;

}