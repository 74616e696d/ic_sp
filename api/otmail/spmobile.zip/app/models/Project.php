<?php

class Project extends Eloquent {

	protected $table = 'projects';
	protected $guarded = ['id'];
    public $timestamps=false;


}
