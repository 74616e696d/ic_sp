<?php

class Comprehension extends Eloquent {
	protected $table = 'comprehension';
	protected $guarded = ['id'];
	public $timestamps=false;


}