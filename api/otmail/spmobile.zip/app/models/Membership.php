<?php

class Membership extends Eloquent {

	protected $table = 'membership';
	protected $guarded = ['id'];
    public $timestamps=false;

   

}
