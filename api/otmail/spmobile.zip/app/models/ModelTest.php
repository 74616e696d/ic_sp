<?php

class ModelTest extends Eloquent {

	protected $table = 'model_test';
	protected $guarded = ['id'];
	public $timestamps=false;

}