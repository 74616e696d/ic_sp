<?php

return array(

	'apiKey' => '2f-BKdSMpOM4XIj5p0Onvw'

);